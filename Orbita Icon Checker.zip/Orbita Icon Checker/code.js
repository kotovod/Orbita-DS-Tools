// Основной код плагина Orbita Icon Checker

// Запуск плагина
figma.showUI(__html__, { width: 400, height: 480 });

// Настройки проверок по умолчанию
const defaultCheckSettings = {
  naming: true,
  variants: true,
  sizes: true,
  structure: true,
  constraints: true,
  vector: true,
  editGroup: true,
  description: true // Проверка description варианта компонента
};

// Текущие настройки проверок
let checkSettings = Object.assign({}, defaultCheckSettings);

// Обработка сообщений от UI
figma.ui.onmessage = async (msg) => {
  try {
    if (msg.type === 'check-icons') {
      // Обновляем настройки проверок, если они переданы
      if (msg.settings) {
        checkSettings = msg.settings;
      }
      
      // Начинаем проверку иконок
      figma.ui.postMessage({ type: 'progress', message: 'Начинаем проверку иконок...', percent: 0 });
      
      const results = await checkIcons(checkSettings);
      
      // Отправляем результаты в UI
      figma.ui.postMessage({ type: 'check-results', results });
    } else if (msg.type === 'focus-node') {
      // Фокусировка на компоненте с ошибкой
      const node = figma.getNodeById(msg.nodeId);
      if (node) {
        figma.currentPage.selection = [node];
        figma.viewport.scrollAndZoomIntoView([node]);
      } else {
        figma.ui.postMessage({
          type: 'error',
          message: 'Не удалось найти компонент. Возможно, он был удален или перемещен.'
        });
      }
    } else if (msg.type === 'fix-error') {
      // Исправление конкретной ошибки
      const result = await fixError(msg.nodeId, msg.errorType);
      figma.ui.postMessage({ type: 'fix-result', result });
    } else if (msg.type === 'fix-all-errors') {
      // Исправление всех ошибок
      figma.ui.postMessage({ type: 'progress', message: 'Исправление ошибок...', percent: 0 });
      const result = await fixAllErrors(msg.results);
      figma.ui.postMessage({ type: 'fix-all-result', result });
    } else if (msg.type === 'get-settings') {
      // Отправляем текущие настройки проверок в UI
      figma.ui.postMessage({ type: 'settings', settings: checkSettings });
    } else if (msg.type === 'update-settings') {
      // Обновляем настройки проверок
      checkSettings = msg.settings;
      figma.ui.postMessage({ type: 'settings-updated', settings: checkSettings });
    } else if (msg.type === 'close-plugin') {
      figma.closePlugin();
    }
  } catch (error) {
    // Отправляем информацию об ошибке в UI
    figma.ui.postMessage({
      type: 'error',
      message: `Произошла ошибка: ${error.message}`
    });
    console.error('Ошибка в плагине:', error);
  }
};

// Функция проверки иконок с использованием пакетной обработки
async function checkIcons(settings) {
  try {
    const results = [];
    
    // Получаем все компоненты на странице
    figma.ui.postMessage({ type: 'progress', message: 'Поиск компонентов на странице...', percent: 5 });
    const componentSets = figma.currentPage.findAllWithCriteria({
      types: ['COMPONENT_SET']
    });
    
    // Фильтруем компоненты, которые могут быть иконками
    figma.ui.postMessage({ type: 'progress', message: 'Фильтрация иконок...', percent: 10 });
    
    // Проверяем все компоненты, а не только те, которые начинаются с "orb-icon-"
    // Это позволит находить компоненты с неправильным именованием
    const iconComponentSets = componentSets;
    
    // Если компонентов не найдено, возвращаем сообщение
    if (iconComponentSets.length === 0) {
      figma.ui.postMessage({ type: 'progress', message: 'Компоненты не найдены', percent: 100 });
      return [{
        nodeId: null,
        nodeName: 'Ошибка',
        errors: ['Не найдено ни одного компонента. Создайте Component Set для иконок с именем, начинающимся с "orb-icon-"']
      }];
    }
    
    figma.ui.postMessage({
      type: 'progress',
      message: `Найдено ${iconComponentSets.length} наборов компонентов. Начинаем проверку...`,
      percent: 15
    });
    
    // Разбиваем компоненты на пакеты для пакетной обработки
    const BATCH_SIZE = 30; // Размер пакета (можно настроить)
    const batches = [];
    
    for (let i = 0; i < iconComponentSets.length; i += BATCH_SIZE) {
      batches.push(iconComponentSets.slice(i, i + BATCH_SIZE));
    }
    
    // Функция для обработки одного пакета компонентов
    const processBatch = (batchIndex) => {
      return new Promise((resolve) => {
        setTimeout(() => {
          const batch = batches[batchIndex];
          const batchResults = [];
          
          // Обрабатываем каждый компонент в пакете
          for (const componentSet of batch) {
            // Обновляем прогресс для каждого пакета
            const processedSets = batchIndex * BATCH_SIZE + batch.indexOf(componentSet) + 1;
            const totalSets = iconComponentSets.length;
            const progressPercent = Math.floor(15 + (processedSets / totalSets) * 75);
            
            figma.ui.postMessage({
              type: 'progress',
              message: `Проверка набора ${processedSets} из ${totalSets}: ${componentSet.name}`,
              percent: progressPercent
            });
            
            // Проверяем каждый вариант в наборе
            if (!componentSet.children || !Array.isArray(componentSet.children)) {
              figma.ui.postMessage({
                type: 'error',
                message: `Компонент ${componentSet.name} не содержит вариантов`
              });
              continue;
            }
            
            // Проверка имени компонента (только один раз для всего Component Set)
            if (settings.naming) {
              let componentSetErrors = [];
              
              // Проверяем, что имя начинается с "orb-icon-"
              if (!componentSet.name.startsWith('orb-icon-')) {
                componentSetErrors.push({
                  type: 'naming',
                  message: 'Неправильное именование иконки. Должно начинаться с: orb-icon-',
                  tooltip: 'Выберите компонент → Нажмите правой кнопкой мыши → Выберите "Rename" → Введите имя в формате "orb-icon-name", где name - название иконки в нижнем регистре с дефисами вместо пробелов'
                });
              }
              // Проверяем, что после префикса есть название иконки
              else if (componentSet.name === 'orb-icon-' || componentSet.name.length <= 9) {
                componentSetErrors.push({
                  type: 'naming',
                  message: 'Отсутствует название иконки после префикса orb-icon-',
                  tooltip: 'Выберите компонент → Нажмите правой кнопкой мыши → Выберите "Rename" → Добавьте название иконки после префикса "orb-icon-"'
                });
              }
              // Проверяем, что название содержит только допустимые символы
              else if (!componentSet.name.substring(9).match(/^[a-z0-9-]+$/)) {
                componentSetErrors.push({
                  type: 'naming',
                  message: 'Название иконки должно содержать только строчные буквы, цифры и дефисы',
                  tooltip: 'Выберите компонент → Нажмите правой кнопкой мыши → Выберите "Rename" → Используйте только строчные буквы, цифры и дефисы в названии иконки'
                });
              }
              
              // Если есть ошибки именования, добавляем их в результаты сразу
              if (componentSetErrors.length > 0) {
                batchResults.push({
                  nodeId: componentSet.id, // ID самого Component Set, а не варианта
                  nodeName: componentSet.name,
                  parentName: componentSet.name,
                  errors: componentSetErrors
                });
              }
            }
            
            // Проверка свойств Variant и Size (только один раз для всего Component Set)
            if (settings.variants) {
              let componentSetVariantErrors = [];
              let hasVariantPropertyErrors = false;
              
              // Проверяем наличие свойств Variant и Size у всех вариантов
              for (const component of componentSet.children) {
                const variantProperties = component.variantProperties;
                if (!variantProperties || !variantProperties.Variant || !variantProperties.Size) {
                  hasVariantPropertyErrors = true;
                  break;
                }
                
                // Проверка значений свойств
                if (!['outline', 'solid'].includes(variantProperties.Variant) ||
                    !['lg', 'md', 'sm', 'xs', 'xxs'].includes(variantProperties.Size)) {
                  hasVariantPropertyErrors = true;
                  break;
                }
              }
              
              // Если есть ошибки, добавляем одну общую ошибку для всего Component Set
              if (hasVariantPropertyErrors) {
                componentSetVariantErrors.push({
                  type: 'variants',
                  message: 'Отсутствуют или неправильно заданы свойства Variant и/или Size',
                  tooltip: 'Выберите компонент → Откройте панель свойств (правый сайдбар) → В разделе Properties добавьте свойства Variant (со значениями outline/solid) и Size (со значениями lg/md/sm/xs/xxs)'
                });
                
                // Добавляем ошибку в результаты сразу
                batchResults.push({
                  nodeId: componentSet.id, // ID самого Component Set, а не варианта
                  nodeName: componentSet.name,
                  parentName: componentSet.name,
                  errors: componentSetVariantErrors
                });
              }
            }
            
            // Проверка вариантов компонента
            for (const component of componentSet.children) {
              const errors = [];
              
              // Проверка размеров
              if (settings.sizes) {
                const validSizes = [
                  { width: 32, height: 32 },
                  { width: 24, height: 24 },
                  { width: 16, height: 16 },
                  { width: 12, height: 12 },
                  { width: 8, height: 8 }
                ];
                
                const sizeIsValid = validSizes.some(size =>
                  component.width === size.width && component.height === size.height
                );
                
                if (!sizeIsValid) {
                  errors.push({
                    type: 'sizes',
                    message: 'Неправильный размер иконки. Должен быть 32x32, 24x24, 16x16, 12x12 или 8x8 px',
                    tooltip: 'Выберите компонент → Откройте панель свойств (правый сайдбар) → В разделе Size установите одинаковые значения для W и H (32, 24, 16, 12 или 8)'
                  });
                }
              }
              
              // Проверка структуры (Color-layer и Vector)
              if (settings.structure) {
                let colorLayer = null;
                let vectorLayer = null;
                
                // Ищем слой Color-layer и Vector на верхнем уровне
                if (!component.children || !Array.isArray(component.children)) {
                  errors.push({
                    type: 'structure',
                    message: 'Компонент не содержит слоев',
                    tooltip: 'Выберите компонент → Добавьте слой Color-layer (Frame) → Внутри него создайте слой Vector'
                  });
                  continue;
                }
                
                // Проверяем наличие слоев Color-layer и Vector на верхнем уровне
                // Также проверяем наличие слоев с похожими, но неправильными именами
                let hasIncorrectLayerName = false;
                
                for (const child of component.children) {
                  // Проверка имени слоя (регистр и дефис важны)
                  const childName = child.name.toLowerCase();
                  
                  if (child.name === 'Color-layer') {
                    colorLayer = child;
                  } else if (child.name === 'Vector') {
                    vectorLayer = child;
                  } else if (childName === 'color' ||
                            childName === 'color-layer' ||
                            childName === 'color layer' ||
                            childName === 'colorlayer' ||
                            child.name === 'Color layer' ||
                            child.name === 'ColorLayer') {
                    // Проверка неправильного именования слоя Color-layer
                    hasIncorrectLayerName = true;
                    errors.push({
                      type: 'structure',
                      message: `Неправильное именование слоя "${child.name}". Должно быть: Color-layer`,
                      tooltip: 'Выберите слой → Нажмите правой кнопкой мыши → Выберите "Rename" → Введите имя "Color-layer" (с учетом регистра и дефиса)'
                    });
                  }
                }
                
                // Добавляем отладочную информацию
                console.log(`Проверка слоя Color-layer для компонента ${component.name}:`, {
                  hasColorLayer: !!colorLayer,
                  hasVectorLayer: !!vectorLayer,
                  hasIncorrectLayerName: hasIncorrectLayerName,
                  childrenNames: component.children ? component.children.map(c => c.name) : []
                });
                
                // Vector должен находиться только внутри Color-layer
                if (!colorLayer) {
                  errors.push({
                    type: 'structure',
                    message: 'Отсутствует слой Color-layer',
                    tooltip: 'Выберите компонент → Добавьте слой Color-layer (Frame) → Внутри него создайте слой Vector'
                  });
                } else {
                  // Если Vector найден на верхнем уровне, это ошибка
                  if (vectorLayer) {
                    errors.push({
                      type: 'structure',
                      message: 'Слой Vector должен находиться внутри Color-layer, а не на верхнем уровне',
                      tooltip: 'Переместите слой Vector внутрь слоя Color-layer'
                    });
                  }
                  // Проверка выравнивания Color-layer по центру
                  if (settings.constraints && colorLayer) {
                    // Временно отключаем проверку выравнивания, так как она работает некорректно
                    // Пользователь должен самостоятельно проверить, что слой Color-layer выровнен по центру
                    
                    // Выводим отладочную информацию о constraints
                    console.log(`Проверка constraints для Color-layer в компоненте ${component.name}:`, {
                      hasConstraints: !!colorLayer.constraints,
                      horizontal: colorLayer.constraints ? colorLayer.constraints.horizontal : 'undefined',
                      vertical: colorLayer.constraints ? colorLayer.constraints.vertical : 'undefined',
                      rawConstraints: colorLayer.constraints
                    });
                    
                    // Проверка временно отключена из-за проблем с определением правильного выравнивания
                    // Будет включена после дополнительного тестирования
                  }
                  
                  // Проверка наличия Vector внутри Color-layer
                  if (settings.vector) {
                    let vectorFound = false;
                    if (!colorLayer.children || !Array.isArray(colorLayer.children)) {
                      errors.push({
                        type: 'vector',
                        message: 'Слой Color-layer не содержит дочерних элементов',
                        tooltip: 'Выберите слой Color-layer → Добавьте внутрь него слой Vector'
                      });
                    } else {
                      for (const child of colorLayer.children) {
                        if (child.name === 'Vector') {
                          vectorFound = true;
                          
                          // Проверка блокировки Vector
                          if (!child.locked) {
                            errors.push({
                              type: 'vector',
                              message: 'Слой Vector должен быть заблокирован (Lock)',
                              tooltip: 'Выберите слой Vector → Нажмите на иконку замка в панели свойств или используйте сочетание клавиш Ctrl+Shift+L (Cmd+Shift+L на Mac)'
                            });
                          }
                          
                          // Проверка типа Vector (должен быть VECTOR, не STROKE)
                          if (child.type !== 'VECTOR') {
                            errors.push({
                              type: 'vector',
                              message: 'Слой Vector должен быть в кривых (не Stroke)',
                              tooltip: 'Выберите слой Vector → Убедитесь, что он создан как векторный объект (не как линия или фигура со stroke) → При необходимости преобразуйте в векторный объект через меню Object → Flatten'
                            });
                          }
                          
                          // Проверка цвета Vector (не должен иметь цвета)
                          if (child.fills && child.fills.length > 0) {
                            errors.push({
                              type: 'vector',
                              message: 'Слой Vector не должен иметь цвета. Цвет должен назначаться через Color-layer',
                              tooltip: 'Выберите слой Vector → Откройте панель свойств (правый сайдбар) → В разделе Fill удалите все цвета → Цвет должен быть назначен слою Color-layer'
                            });
                          }
                          
                          break;
                        }
                      }
                    }
                    
                    if (!vectorFound) {
                      errors.push({
                        type: 'vector',
                        message: 'Отсутствует слой Vector внутри Color-layer',
                        tooltip: 'Выберите слой Color-layer → Добавьте внутрь него слой Vector → Убедитесь, что слой Vector создан как векторный объект'
                      });
                    }
                  }
                }
              }
              
              // Проверка наличия группы Edit
              if (settings.editGroup) {
                let editGroupFound = false;
                if (component.children && Array.isArray(component.children)) {
                  for (const child of component.children) {
                    if (child.name === 'Edit' && child.type === 'GROUP') {
                      editGroupFound = true;
                      
                      // Проверка видимости группы Edit
                      if (child.visible) {
                        errors.push({
                          type: 'editGroup',
                          message: 'Группа Edit должна быть скрыта',
                          tooltip: 'Выберите группу Edit → Нажмите на иконку глаза в панели слоев, чтобы скрыть группу'
                        });
                      }
                      
                      break;
                    }
                  }
                }
                
                if (!editGroupFound) {
                  errors.push({
                    type: 'editGroup',
                    message: 'Отсутствует группа Edit для хранения исходника иконки',
                    tooltip: 'Создайте новую группу с именем Edit → Поместите в нее исходные файлы или элементы для редактирования иконки → Скройте группу, нажав на иконку глаза в панели слоев'
                  });
                }
              }
              
              // Проверка description варианта компонента
              if (settings.description) {
                // Получаем значения Variant и Size
                const variant = (component.variantProperties && component.variantProperties.Variant) ? component.variantProperties.Variant : 'outline';
                const size = (component.variantProperties && component.variantProperties.Size) ? component.variantProperties.Size : 'md';
                
                // Ищем соседний компонент Instance "source-token-name"
                let sourceTokenName = '';
                let sourceTokenFound = false;
                
                // Ищем на текущей странице
                const instances = figma.currentPage.findAllWithCriteria({
                  types: ['INSTANCE']
                });
                
                for (const instance of instances) {
                  if (instance.name === 'source-token-name') {
                    sourceTokenFound = true;
                    // Ищем текстовый слой Label внутри instance
                    if (instance.children && Array.isArray(instance.children)) {
                      for (const child of instance.children) {
                        if (child.name === 'Label' && child.type === 'TEXT') {
                          sourceTokenName = child.characters;
                          break;
                        }
                      }
                    }
                    break;
                  }
                }
                
                // Если не нашли source-token-name, используем имя компонента без префикса
                if (!sourceTokenFound) {
                  sourceTokenName = componentSet.name.replace('orb-icon-', '');
                }
                
                // Формируем ожидаемый description
                const expectedDescription = `${sourceTokenName}-${variant}-${size}`;
                
                // Проверяем description компонента
                if (!component.description || component.description !== expectedDescription) {
                  errors.push({
                    type: 'description',
                    message: `Неправильный description компонента. Должен быть: ${expectedDescription}`,
                    tooltip: 'Откройте панель свойств компонента (правый сайдбар) → Найдите поле Description → Введите значение в формате "name-variant-size", где name - название иконки, variant - тип (outline/solid), size - размер (lg/md/sm/xs/xxs). Учитывайте нижний регистр'
                  });
                }
              }
              
              // Добавляем результаты проверки, если есть ошибки (кроме ошибок именования компонента)
              if (errors.length > 0) {
                batchResults.push({
                  nodeId: component.id,
                  nodeName: component.name,
                  parentName: componentSet.name,
                  errors: errors
                });
              }
            }
          }
          
          // Добавляем результаты пакета в общие результаты
          results.push(...batchResults);
          
          // Возвращаем результаты пакета
          resolve(batchResults);
        }, 0); // setTimeout с нулевой задержкой для разгрузки основного потока
      });
    };
    
    // Последовательная обработка пакетов
    for (let i = 0; i < batches.length; i++) {
      await processBatch(i);
      
      // Обновляем общий прогресс после каждого пакета
      const batchProgress = Math.floor(15 + ((i + 1) / batches.length) * 80);
      figma.ui.postMessage({
        type: 'progress',
        message: `Обработано ${i + 1} из ${batches.length} пакетов...`,
        percent: batchProgress
      });
    }
    
    figma.ui.postMessage({ type: 'progress', message: 'Проверка завершена', percent: 100 });
    return results;
  } catch (error) {
    figma.ui.postMessage({
      type: 'error',
      message: `Ошибка при проверке иконок: ${error.message}`
    });
    console.error('Ошибка при проверке иконок:', error);
    return [{
      nodeId: null,
      nodeName: 'Ошибка',
      errors: [`Произошла ошибка при проверке иконок: ${error.message}`]
    }];
  }
}

// Функция исправления конкретной ошибки
async function fixError(nodeId, errorType) {
  try {
    const node = figma.getNodeById(nodeId);
    if (!node) {
      return { success: false, message: 'Не удалось найти компонент' };
    }
    
    const componentSet = node.parent;
    if (!componentSet) {
      return { success: false, message: 'Не удалось найти родительский компонент' };
    }
    
    switch (errorType) {
      case 'naming':
        // Исправление имени компонента
        let newName = componentSet.name;
        
        // Если имя не начинается с "orb-icon-", добавляем префикс
        if (!newName.startsWith('orb-icon-')) {
          newName = 'orb-icon-' + newName.replace(/^orb-icon-/i, '');
        }
        
        // Преобразуем название после префикса в нижний регистр и заменяем недопустимые символы на дефисы
        const prefix = 'orb-icon-';
        const iconName = newName.substring(prefix.length);
        const cleanIconName = iconName.toLowerCase().replace(/[^a-z0-9-]/g, '-');
        
        // Если после очистки название пустое, добавляем "icon"
        const finalIconName = cleanIconName.length > 0 ? cleanIconName : 'icon';
        
        // Формируем итоговое имя
        const finalName = prefix + finalIconName;
        
        // Устанавливаем новое имя
        componentSet.name = finalName;
        
        return { success: true, message: `Имя компонента исправлено на "${finalName}"` };
        
      case 'variants':
        // Исправление свойств Variant и Size
        if (!node.variantProperties) {
          return { success: false, message: 'Компонент не имеет свойств вариантов' };
        }
        
        // Определяем размер по ширине компонента
        let size = 'md';
        if (node.width === 32) size = 'lg';
        else if (node.width === 24) size = 'md';
        else if (node.width === 16) size = 'sm';
        else if (node.width === 12) size = 'xs';
        else if (node.width === 8) size = 'xxs';
        
        // Устанавливаем свойства
        node.setProperties({
          Variant: node.variantProperties.Variant === 'solid' ? 'solid' : 'outline',
          Size: size
        });
        
        return { success: true, message: 'Свойства вариантов исправлены' };
        
      case 'sizes':
        // Исправление размеров компонента
        // Определяем правильный размер по свойству Size
        let targetSize = { width: 24, height: 24 }; // md по умолчанию
        
        if (node.variantProperties && node.variantProperties.Size) {
          const sizeProperty = node.variantProperties.Size;
          if (sizeProperty === 'lg') targetSize = { width: 32, height: 32 };
          else if (sizeProperty === 'md') targetSize = { width: 24, height: 24 };
          else if (sizeProperty === 'sm') targetSize = { width: 16, height: 16 };
          else if (sizeProperty === 'xs') targetSize = { width: 12, height: 12 };
          else if (sizeProperty === 'xxs') targetSize = { width: 8, height: 8 };
        }
        
        node.resize(targetSize.width, targetSize.height);
        return { success: true, message: 'Размер компонента исправлен' };
        
      case 'structure':
        // Исправление структуры (добавление слоя Color-layer или исправление имени)
        if (!node.children || !Array.isArray(node.children)) {
          return { success: false, message: 'Компонент не содержит слоев' };
        }
        
        // Проверяем наличие Color-layer, Vector и слоев с неправильным именем
        let colorLayer = null;
        let vectorLayer = null;
        let incorrectNamedLayer = null;
        
        for (const child of node.children) {
          const childName = child.name.toLowerCase();
          
          if (child.name === 'Color-layer') {
            colorLayer = child;
          } else if (child.name === 'Vector') {
            vectorLayer = child;
          } else if (childName === 'color' ||
                    childName === 'color-layer' ||
                    childName === 'color layer' ||
                    childName === 'colorlayer' ||
                    child.name === 'Color layer' ||
                    child.name === 'ColorLayer') {
            incorrectNamedLayer = child;
          }
        }
        
        // Если найден слой с неправильным именем, исправляем его
        if (incorrectNamedLayer) {
          incorrectNamedLayer.name = 'Color-layer';
          return { success: true, message: 'Имя слоя исправлено на Color-layer' };
        }
        
        // Если нет ни Color-layer, ни Vector, создаем Color-layer
        if (!colorLayer && !vectorLayer) {
          colorLayer = figma.createFrame();
          colorLayer.name = 'Color-layer';
          node.appendChild(colorLayer);
        }
        
        return { success: true, message: 'Структура компонента исправлена' };
        
      case 'constraints':
        // Исправление выравнивания Color-layer
        if (!node.children || !Array.isArray(node.children)) {
          return { success: false, message: 'Компонент не содержит слоев' };
        }
        
        // Находим Color-layer
        let colorLayerForConstraints = null;
        for (const child of node.children) {
          if (child.name === 'Color-layer') {
            colorLayerForConstraints = child;
            break;
          }
        }
        
        if (!colorLayerForConstraints) {
          return { success: false, message: 'Слой Color-layer не найден' };
        }
        
        // Устанавливаем выравнивание по центру
        // Это базовое выравнивание, которое должно работать в большинстве случаев
        // Если возникнут проблемы, пользователь может вручную настроить выравнивание
        colorLayerForConstraints.constraints = {
          horizontal: 'CENTER',
          vertical: 'CENTER'
        };
        
        return { success: true, message: 'Выравнивание Color-layer исправлено' };
        
      case 'vector':
        // Исправление Vector (блокировка, тип, цвет)
        if (!node.children || !Array.isArray(node.children)) {
          return { success: false, message: 'Компонент не содержит слоев' };
        }
        
        // Сначала проверяем наличие Vector на верхнем уровне
        let vector = null;
        for (const child of node.children) {
          if (child.name === 'Vector') {
            vector = child;
            break;
          }
        }
        
        // Если Vector не найден на верхнем уровне, ищем его в Color-layer
        if (!vector) {
          // Находим Color-layer
          let colorLayerForVector = null;
          for (const child of node.children) {
            if (child.name === 'Color-layer') {
              colorLayerForVector = child;
              break;
            }
          }
          
          if (!colorLayerForVector) {
            return { success: false, message: 'Слой Color-layer не найден' };
          }
          
          // Находим Vector в Color-layer
          if (colorLayerForVector.children && Array.isArray(colorLayerForVector.children)) {
            for (const child of colorLayerForVector.children) {
              if (child.name === 'Vector') {
                vector = child;
                break;
              }
            }
          }
        }
        
        if (!vector) {
          return { success: false, message: 'Слой Vector не найден' };
        }
        
        // Блокируем Vector
        vector.locked = true;
        
        return { success: true, message: 'Слой Vector исправлен' };
        
      case 'editGroup':
        // Исправление группы Edit (создание и скрытие)
        if (!node.children || !Array.isArray(node.children)) {
          return { success: false, message: 'Компонент не содержит слоев' };
        }
        
        // Проверяем наличие группы Edit
        let editGroup = null;
        for (const child of node.children) {
          if (child.name === 'Edit' && child.type === 'GROUP') {
            editGroup = child;
            break;
          }
        }
        
        // Если нет группы Edit, создаем ее
        if (!editGroup) {
          editGroup = figma.group([], node);
          editGroup.name = 'Edit';
        }
        
        // Скрываем группу Edit
        editGroup.visible = false;
        
        return { success: true, message: 'Группа Edit исправлена' };
        
      case 'description':
        // Исправление description компонента
        if (!node.variantProperties) {
          return { success: false, message: 'Компонент не имеет свойств вариантов' };
        }
        
        // Получаем значения Variant и Size
        const variant = node.variantProperties.Variant || 'outline';
        const sizeValue = node.variantProperties.Size || 'md';
        
        // Ищем соседний компонент Instance "source-token-name"
        let sourceTokenName = '';
        let sourceTokenFound = false;
        
        // Ищем на текущей странице
        const instances = figma.currentPage.findAllWithCriteria({
          types: ['INSTANCE']
        });
        
        for (const instance of instances) {
          if (instance.name === 'source-token-name') {
            sourceTokenFound = true;
            // Ищем текстовый слой Label внутри instance
            if (instance.children && Array.isArray(instance.children)) {
              for (const child of instance.children) {
                if (child.name === 'Label' && child.type === 'TEXT') {
                  sourceTokenName = child.characters;
                  break;
                }
              }
            }
            break;
          }
        }
        
        // Если не нашли source-token-name, используем имя компонента без префикса
        if (!sourceTokenFound) {
          const componentSet = node.parent;
          if (componentSet) {
            sourceTokenName = componentSet.name.replace('orb-icon-', '');
          }
        }
        
        // Формируем ожидаемый description
        const expectedDescription = `${sourceTokenName}-${variant}-${sizeValue}`;
        
        // Устанавливаем description компонента
        node.description = expectedDescription;
        
        return { success: true, message: 'Description компонента исправлен' };
        
      default:
        return { success: false, message: 'Неизвестный тип ошибки' };
    }
  } catch (error) {
    console.error('Ошибка при исправлении:', error);
    return { success: false, message: `Ошибка при исправлении: ${error.message}` };
  }
}

// Функция исправления всех ошибок
async function fixAllErrors(results) {
  try {
    const fixResults = [];
    let processedCount = 0;
    const totalCount = results.length;
    
    for (const result of results) {
      processedCount++;
      const progressPercent = Math.floor((processedCount / totalCount) * 100);
      
      figma.ui.postMessage({
        type: 'progress',
        message: `Исправление ошибок (${processedCount}/${totalCount})`,
        percent: progressPercent
      });
      
      // Получаем уникальные типы ошибок для этого компонента
      const errorTypes = [...new Set(result.errors.map(error => error.type))];
      
      // Исправляем каждый тип ошибки
      for (const errorType of errorTypes) {
        const fixResult = await fixError(result.nodeId, errorType);
        fixResults.push({
          nodeId: result.nodeId,
          nodeName: result.nodeName,
          errorType: errorType,
          success: fixResult.success,
          message: fixResult.message
        });
      }
    }
    
    figma.ui.postMessage({ type: 'progress', message: 'Исправление завершено', percent: 100 });
    
    return {
      success: true,
      message: `Исправлено ${fixResults.filter(r => r.success).length} из ${fixResults.length} ошибок`,
      details: fixResults
    };
  } catch (error) {
    console.error('Ошибка при исправлении всех ошибок:', error);
    return {
      success: false,
      message: `Ошибка при исправлении всех ошибок: ${error.message}`
    };
  }
}